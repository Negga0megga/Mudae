namespace MudaeFarm
{
    public enum KakeraType
    {
        Purple,
        Blue,
        Teal,
        Green,
        Yellow,
        Orange,
        Red,
        Rainbow
    }
}