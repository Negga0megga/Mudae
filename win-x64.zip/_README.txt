You need to look for the file "MudaeFarm.exe".
